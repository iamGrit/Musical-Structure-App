package com.gritlab.geevesmp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

public class AudioNowPlayingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audio_now_playing);
        setSongTitle();
        setArtiste();

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    public void setSongTitle() {
        TextView songTitleView = findViewById(R.id.now_playing_song_title);
        songTitleView.setText(AudioActivity.getSongTitle());
    }

    public void setArtiste() {
        TextView artisteView = findViewById(R.id.now_playing_artiste);
        artisteView.setText(AudioActivity.getArtiste());

    }
}
