package com.gritlab.geevesmp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class AudioActivity extends AppCompatActivity {

    private static String songTitle;
    private static String artiste;


    //Getter methods for the variable

    public static String getArtiste() {
        return artiste;
    }

    public static String getSongTitle() {
        return songTitle;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        //Make array of audio files getting Artiste name and titles using the Word class

        final ArrayList<Word> words = new ArrayList<>();
        words.add(new Word("asdfasd", "dfasdfa"));
        words.add(new Word("asdfasd", "dfasdfa"));
        words.add(new Word("asdfasd", "dfasdfa"));
        words.add(new Word("asdfasd", "dfasdfa"));
        words.add(new Word("asdfasd", "dfasdfa"));
        words.add(new Word("asdfasd", "dfasdfa"));
        words.add(new Word("asdfasd", "dfasdfa"));
        words.add(new Word("asdfasd", "dfasdfa"));
        words.add(new Word("asdfasd", "dfasdfa"));
        words.add(new Word("asdfasd", "dfasdfa"));
        words.add(new Word("asdfasd", "dfasdfa"));
        words.add(new Word("asdfasd", "dfasdfa"));
        words.add(new Word("asdfasd", "dfasdfa"));
        words.add(new Word("asdfasd", "dfasdfa"));
        words.add(new Word("asdfasd", "dfasdfa"));
        words.add(new Word("asdfasd", "dfasdfa"));
        words.add(new Word("asdfasd", "dfasdfa"));
        words.add(new Word("asdfasd", "dfasdfa"));
        words.add(new Word("asdfasd", "dfasdfa"));


        WordAdapter wordAdapter = new WordAdapter(this, words);


        ListView listView = findViewById(R.id.list);

        listView.setAdapter(wordAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                // get the position of the list item that was clicked and store it
                Word word = words.get(position);
                // gets the assosciated song title and artiste name of that list item and stores it
                songTitle = word.getSongTitle();
                artiste = word.getArtiste();

                //Opens a new activity when the button is clicked
                Intent intent;
                switch (position) {

                    default:
                        intent = new Intent(getApplicationContext(), AudioNowPlayingActivity.class);
                        startActivity(intent);
                }

            }

        });


    }

}

class ViewHolder {
    TextView songTitle;
    TextView artiste;
}