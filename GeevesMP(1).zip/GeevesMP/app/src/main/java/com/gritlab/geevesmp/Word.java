package com.gritlab.geevesmp;


//Class used to populate the array for the media list
public class Word {

    private String mSongTitle;
    private String mArtiste;

    Word(String songTitle, String artiste){
        mSongTitle = songTitle;
        mArtiste = artiste;
    }

    //Getter metthods for the variables
    public String getArtiste() {
        return mArtiste;
    }

    public String getSongTitle() {
        return mSongTitle;
    }
}
