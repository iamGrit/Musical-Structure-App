package com.gritlab.geevesmp;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class WordAdapter extends ArrayAdapter<Word> {


    WordAdapter(Activity context, ArrayList<Word> words) {
        super(context, 0, words);

    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        ViewHolder holder = new ViewHolder();;

        //Checks that there is no re-usable view and creates a new one
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_layout, parent, false);
            holder.songTitle = convertView.findViewById(R.id.list_layout_song_title);
            holder.artiste = convertView.findViewById(R.id.list_layout_artiste);
            convertView.setTag(holder);
        }
        else {
            holder = (ViewHolder) convertView.getTag();
        }


        Word currentWord = getItem(position);

        holder.songTitle.setText(currentWord.getSongTitle());

        holder.songTitle.setText(currentWord.getArtiste());


        return convertView;

    }
}
